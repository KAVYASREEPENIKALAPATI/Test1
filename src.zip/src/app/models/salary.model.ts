export class Salary{
 HRA:number;
 DA:number;
 Bonous:string;
 BasicSal:number;
 
 constructor(hra,da,bonous,basic){
this.HRA=hra;
this.DA=da;
this.Bonous=bonous;
this.BasicSal=basic;
 }
}