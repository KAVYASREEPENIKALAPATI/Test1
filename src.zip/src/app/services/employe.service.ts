// import {Employe} from '../models/employe.model';
// import {Salary} from '../models/salary.model';
// export class EmployeService{
//     employes:Employe[];
//     total:string;

//     constructor(){
//         this.employes=[new Employe("r43","sam",33,
//     [new Salary(22,33,"pf",76),
// new Salary(34,33,"esi",344)])];

//     }
//     getEmploye():Employe[]{
//         return this.employes;
//     }
//     addEmploye(){
//         this.employes.push(employe);
//     }
// }